import React from 'react';
const io = require('socket.io-client')

const iceConfig = {iceServers: [{urls: ['stun:stun.l.google.com:19302']}]}
const rtcPeerConn = new RTCPeerConnection(iceConfig);
const myNum = "9836009113";
const serverAddress = "192.168.0.1:4000";
const socket = io(serverAddress, {query: {number: myNum}});
var mediaStream = new MediaStream();

export default class Stream extends React.Component{
    async componentDidMount(){
        var video = document.querySelector('video');
        socket.on("offer", async (offerObj) => {
            rtcPeerConn.setRemoteDescription(offerObj.offer);
            var answer = await rtcPeerConn.createAnswer();
            rtcPeerConn.setLocalDescription(answer);
            var answerObj = {
                from: socket.id,
                to: offerObj.from,
                answer: answer
            };
            socket.emit("answer", answerObj);
        })

        socket.on("candidate", (candidate) => {
            rtcPeerConn.addIceCandidate(candidate.candidate);
        })

        rtcPeerConn.ontrack = (event) => {
            event.track.onunmute = () => {
                video.srcObject = event.streams[0];
            }
        }

        rtcPeerConn.oniceconnectionstatechange = () => {
            console.log(rtcPeerConn.iceConnectionState);
        }
        rtcPeerConn.onicegatheringstatechange = () => {
            console.log(rtcPeerConn.iceGatheringState)
        }
        
    }
    render(){
        return (
            <div>
                <video width="960" height = "540" autoPlay></video>
            </div>
        )
    }
}