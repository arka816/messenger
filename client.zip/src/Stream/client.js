// CLIENT SIDE SCRIPT

import React from 'react';
const io = require('socket.io-client')

//create the connection to the server
const myNum = "8420595895"
const serverAddress = "http://localhost:4000"
const socket = io(serverAddress, {query: {number: myNum}});

export default class Messenger extends React.Component{
    async componentDidMount(){
        socket.on("message", (messageObj) => {
            var sender = messageObj.from
            var message = messageObj.message
            // display message in sender's window
            document.getElementById('msg').innerHTML += message
        })        
    }
    sendMessage = () => {
        // send the message to the server
        // send button triggers this function
        var message = document.getElementById('writemsg').value
        var phoneNum = "9836009113"
        var messageObj = {
            from: socket.id,
            to: phoneNum,
            message: message
        };
        socket.emit("message", messageObj);
    }
    render(){
        return (
            <div>
                <input id="writemsg"></input>
                <button onClick={this.sendMessage}>SEND</button>
                <span id="msg"></span>
            </div>
        )
    }
}