import React from 'react';
import Stream from "./Stream/stream"
import Messenger from "./Stream/client"

class App extends React.Component{
	render(){
		return (
			<Messenger />
		);
	}
}

export default App;